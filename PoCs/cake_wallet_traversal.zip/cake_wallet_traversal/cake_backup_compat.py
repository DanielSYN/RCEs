#!/usr/bin/env python3
"""Shared cake_backup V2 crypto compatible with Dart cake_backup/lib/backup.dart"""
import os, hashlib
import nacl.bindings

AAD = b"Cake Wallet backup v2"
VERSION = 2
PBKDF_ITERS = 120000
SALT_LEN = 16
NONCE_LEN = 24
TAG_LEN = 16
CHECKSUM_LEN = 64

def encrypt_v2(passphrase: str, plaintext: bytes) -> bytes:
    salt = os.urandom(SALT_LEN)
    key = hashlib.pbkdf2_hmac('sha512', passphrase.encode('utf-8'), salt, PBKDF_ITERS, dklen=32)
    nonce = os.urandom(NONCE_LEN)
    ct_and_tag = nacl.bindings.crypto_aead_xchacha20poly1305_ietf_encrypt(plaintext, AAD, nonce, key)
    ciphertext, tag = ct_and_tag[:-TAG_LEN], ct_and_tag[-TAG_LEN:]
    h = hashlib.blake2b(digest_size=CHECKSUM_LEN)
    h.update(bytes([len(AAD)])); h.update(AAD); h.update(bytes([VERSION]))
    h.update(salt); h.update(nonce); h.update(tag); h.update(ciphertext)
    checksum = h.digest()
    return bytes([VERSION]) + salt + nonce + tag + checksum + ciphertext

def decrypt_v2(passphrase: str, blob: bytes) -> bytes:
    if len(blob) < 1+SALT_LEN+NONCE_LEN+TAG_LEN+CHECKSUM_LEN:
        raise ValueError("too short")
    if blob[0] != VERSION:
        raise ValueError(f"bad version {blob[0]}")
    o=1
    salt=blob[o:o+SALT_LEN]; o+=SALT_LEN
    nonce=blob[o:o+NONCE_LEN]; o+=NONCE_LEN
    tag=blob[o:o+TAG_LEN]; o+=TAG_LEN
    checksum=blob[o:o+CHECKSUM_LEN]; o+=CHECKSUM_LEN
    ciphertext=blob[o:]
    h=hashlib.blake2b(digest_size=CHECKSUM_LEN)
    h.update(bytes([len(AAD)])); h.update(AAD); h.update(bytes([VERSION]))
    h.update(salt); h.update(nonce); h.update(tag); h.update(ciphertext)
    if h.digest()!=checksum:
        raise ValueError("checksum mismatch")
    key=hashlib.pbkdf2_hmac('sha512', passphrase.encode('utf-8'), salt, PBKDF_ITERS, dklen=32)
    return nacl.bindings.crypto_aead_xchacha20poly1305_ietf_decrypt(ciphertext+tag, AAD, nonce, key)
