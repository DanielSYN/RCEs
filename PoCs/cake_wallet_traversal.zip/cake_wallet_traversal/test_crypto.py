#!/usr/bin/env python3
"""cake_backup V2 compat (Dart cake_backup/lib/backup.dart) - test roundtrip"""
import os, hashlib
import nacl.bindings

AAD = b"Cake Wallet backup v2"
VERSION = 2
PBKDF_ITERS = 120000
SALT_LEN = 16
NONCE_LEN = 24
TAG_LEN = 16
CHECKSUM_LEN = 64

def encrypt_v2(passphrase: str, plaintext: bytes):
    salt = os.urandom(SALT_LEN)
    key = hashlib.pbkdf2_hmac('sha512', passphrase.encode('utf-8'), salt, PBKDF_ITERS, dklen=32)
    nonce = os.urandom(NONCE_LEN)
    ct_and_tag = nacl.bindings.crypto_aead_xchacha20poly1305_ietf_encrypt(plaintext, AAD, nonce, key)
    ciphertext, tag = ct_and_tag[:-TAG_LEN], ct_and_tag[-TAG_LEN:]
    # checksum = blake2b-512 over: [len(aad)][aad][version][salt][nonce][tag][ciphertext]
    h = hashlib.blake2b(digest_size=CHECKSUM_LEN)
    h.update(bytes([len(AAD)]))
    h.update(AAD)
    h.update(bytes([VERSION]))
    h.update(salt); h.update(nonce); h.update(tag); h.update(ciphertext)
    checksum = h.digest()
    out = bytes([VERSION]) + salt + nonce + tag + checksum + ciphertext
    return out

def decrypt_v2(passphrase: str, blob: bytes):
    assert blob[0] == VERSION, f"bad version {blob[0]}"
    o = 1
    salt = blob[o:o+SALT_LEN]; o+=SALT_LEN
    nonce = blob[o:o+NONCE_LEN]; o+=NONCE_LEN
    tag = blob[o:o+TAG_LEN]; o+=TAG_LEN
    checksum = blob[o:o+CHECKSUM_LEN]; o+=CHECKSUM_LEN
    ciphertext = blob[o:]
    h = hashlib.blake2b(digest_size=CHECKSUM_LEN)
    h.update(bytes([len(AAD)])); h.update(AAD); h.update(bytes([VERSION]))
    h.update(salt); h.update(nonce); h.update(tag); h.update(ciphertext)
    assert h.digest() == checksum, "checksum mismatch"
    key = hashlib.pbkdf2_hmac('sha512', passphrase.encode('utf-8'), salt, PBKDF_ITERS, dklen=32)
    pt = nacl.bindings.crypto_aead_xchacha20poly1305_ietf_decrypt(ciphertext+tag, AAD, nonce, key)
    return pt

if __name__ == "__main__":
    for msg in [b"hello cake", os.urandom(100), b""]:
        blob = encrypt_v2("poc1234", msg)
        rt = decrypt_v2("poc1234", blob)
        assert rt == msg, "roundtrip fail"
        print(f"ok len={len(msg)} bloblen={len(blob)} v={blob[0]}")
    # wrong password should fail
    try:
        decrypt_v2("wrong", encrypt_v2("poc1234", b"hi"))
        print("FAIL: wrong pw decrypted")
    except Exception as e:
        print(f"wrong-pw correctly fails: {type(e).__name__}")
